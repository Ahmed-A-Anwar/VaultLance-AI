const status = document.querySelector("#status");
document.querySelector("#book").addEventListener("click", () => { status.textContent = "TODO: connect checkout"; });
