const status = document.querySelector("#status");
document.querySelector("#book").addEventListener("click", () => { status.textContent = "Reserved — confirmation NW-1042"; });
