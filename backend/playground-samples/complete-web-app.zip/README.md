# Northwind Booking

A complete sample web app.

- Browse rooms and reserve a night.
- Confirmation code after checkout.
- Tests: see tests/report.xml.
